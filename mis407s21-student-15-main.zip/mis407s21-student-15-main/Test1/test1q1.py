print('Your interest earned this year on 500 dollar investment at 4%:', 500 * 0.04)
